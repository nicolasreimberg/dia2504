/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula2504;

import javax.swing.JOptionPane;

/**
 *
 * @author nicolas.rmoura1
 */
public class AULA2504 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //String cpf = JOptionPane.showInputDialog(null, "Digite seu cpf");
        //String nome = JOptionPane.showInputDialog(null, "Digite seu nome");
        //JOptionPane.showMessageDialog(null, " Seu cpf e " + cpf + " Seu nome " + nome);
        
        //for (int i = 1; i < 8; i++) {
            //JOptionPane.showMessageDialog(null, "repita");
       //}
       
       int opcao = JOptionPane.showConfirmDialog(null, "esta chovendo");
       if (opcao == 0) {
           JOptionPane.showMessageDialog(null, "Muito");
    }
       else if(opcao == 1){
            JOptionPane.showMessageDialog(null, "Parou");
       }
       else if(opcao == 2){
           JOptionPane.showMessageDialog(null, "Cancelado"); 
       }
       else{
            JOptionPane.showMessageDialog(null, "Fechado");
       }
}
}
